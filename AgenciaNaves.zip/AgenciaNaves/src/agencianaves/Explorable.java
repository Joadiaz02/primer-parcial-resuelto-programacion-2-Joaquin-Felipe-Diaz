package agencianaves;


public interface Explorable {
    void explorar();
}
