
package agencianaves;

public enum TipoDeMision {
    CARTOGRAFIA, INVESTIGACION, CONTACTO;
}

