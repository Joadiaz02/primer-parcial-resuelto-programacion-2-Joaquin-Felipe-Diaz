
package agencianaves;

import java.util.Objects;

public abstract class NaveEspacial {
    private String nombre;
    private int capacidadTripulacion;
    private int lanzamiento;

    public NaveEspacial(String nombre, int capacidadTripulacion, int lanzamiento) {
        this.nombre = nombre;
        this.capacidadTripulacion = capacidadTripulacion;
        this.lanzamiento = lanzamiento;
    }

    public String getNombre() {
        return nombre;
    }

    public int getLanzamiento() {
        return lanzamiento;
    }
    

    public int getCapacidadTripulacion(){
    return capacidadTripulacion;
    }
    
    //public abstract void mostrarInformacion();

    //public void iniciarExploracion() {
    //    System.out.println("Esta nave no tiene misiones de exploracion.");
    //}

    @Override
    public String toString() {
        return "NaveEspacial{" + "nombre=" + nombre + ", capacidadTripulacion=" + capacidadTripulacion + ", lanzamiento=" + lanzamiento + '}';
    }
    
    
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }      
        NaveEspacial otraNave = (NaveEspacial) o;

        return otraNave.getNombre().equals(getNombre()) && otraNave.getLanzamiento() == getLanzamiento();
    }
    
    @Override
    public int hashCode(){
    return Objects.hash(nombre, lanzamiento);
    }

}
