
package agencianaves;

public class NaveExploracion extends NaveEspacial implements Explorable{
    
    private TipoDeMision tipoDeMision;

    public NaveExploracion(String nombre, int capacidadTripulacion, int lanzamiento, TipoDeMision tipoMision) {
        super(nombre, capacidadTripulacion, lanzamiento);
        this.tipoDeMision = tipoMision;
    }

    //@Override
    //public void iniciarExploracion() {
    //    System.out.println(getNombre() + " esta realizando una mision de " + tipoDeMision);
    //}

    //@Override
    //public void mostrarInformacion() {
    //    System.out.println("Nave de Exploracion: Nombre: " + getNombre() + " Capacidad de tripulacion: " + getCapacidadTripulacion() + " Año de lanzamiento: " +
    //            getLanzamiento() + " Tipo de Mision: " + tipoDeMision);
    //}

    @Override
    public String toString() {
        return "NaveExploracion{" + "tipoDeMision=" + tipoDeMision + super.toString();
    }
    
    
    
    @Override
    public void explorar() {
        System.out.println(getNombre() + " esta realizando una mision de " + tipoDeMision);
    }
}


