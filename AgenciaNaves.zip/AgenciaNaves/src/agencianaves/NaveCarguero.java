
package agencianaves;


public class NaveCarguero extends NaveEspacial implements Explorable{
    private int capacidadCarga;
    private static final int MAX_CARGA = 500;
    private static final int MIN_CARGA = 100;
    
    public NaveCarguero(String nombre, int capacidadTripulacion, int lanzamiento, int capacidadCarga) {
        super(nombre, capacidadTripulacion, lanzamiento);
        setCapacidadCarga(capacidadCarga); 
    }

    public void setCapacidadCarga(int capacidadCarga) {
        if (capacidadCarga < MIN_CARGA || capacidadCarga > MAX_CARGA) {
            throw new IllegalArgumentException("La capacidad de carga debe ser de entre 100 y 500 toneladas.");
        }
        this.capacidadCarga = capacidadCarga;
    }

    public int getCapacidadCarga() {
        return capacidadCarga;
    }
    
   // @Override
    //public void iniciarExploracion() {
    //    System.out.println(getNombre() + " esta iniciando una mision.");
    //}

    @Override
    public String toString() {
        return "NaveCarguero{" + "capacidadCarga=" + capacidadCarga + super.toString() ;
    }

    //@Override
    //public void mostrarInformacion() {
    //    System.out.println("Nave Carguero: Nombre: " + getNombre() + " Capacidad de tripulacion: " + getCapacidadTripulacion()+ " Año de lanzamiento: " + getLanzamiento() + " Capacidad de carga: " 
    //            + capacidadCarga + " toneladas");
    //}

    @Override
    public void explorar() {
         System.out.println(getNombre() + " esta iniciando una mision.");
    }
}
