
package agencianaves;

import java.util.ArrayList;
import java.util.List;


public class Agencia {
     private List<NaveEspacial> naves;

    public Agencia() {
        naves = new ArrayList<>();
    }

    public void agregarNave(NaveEspacial nave) throws NaveDuplicadaException{
        if (nave == null) {
            throw new IllegalArgumentException("Argumento invalido");
        }
        for (NaveEspacial n : naves) {
            if (n.equals(nave)) {
                throw new NaveDuplicadaException();
            }
        }
        naves.add(nave);
    }

    public void mostrarNaves() {
        for (NaveEspacial nave : naves) {
            System.out.println(nave);
        }
    }

    

    public void iniciarExploracionDeNaves() {
        for (NaveEspacial nave : naves) {
            if(nave instanceof Explorable explorador){
                explorador.explorar();
            }
        }
    }
}
