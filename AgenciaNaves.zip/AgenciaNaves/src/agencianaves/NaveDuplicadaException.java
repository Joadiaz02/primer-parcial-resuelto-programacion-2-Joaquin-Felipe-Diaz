
package agencianaves;



public class NaveDuplicadaException extends Exception {
   public static final String MESSAGE = "Ya existe una nave con el mismo nombre y año de lanzamiento.";

    public NaveDuplicadaException() {
        super(MESSAGE); 
    }
}
